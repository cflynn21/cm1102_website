from flask import Flask, render_template, session, redirect, request, url_for
from flask_bootstrap import Bootstrap
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed, FileRequired
from wtforms import StringField, IntegerField, TextAreaField, SubmitField, validators, ValidationError
from wtforms.validators import DataRequired, Length
from flask_sqlalchemy import SQLAlchemy
import re
import os
import imghdr

app = Flask(__name__)
app.config['SECRET_KEY'] = 'super duper secret'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.sqlite3'
bootstrap = Bootstrap(app)
db = SQLAlchemy(app)

class addProductsForm(FlaskForm):
    name = StringField('Name',[validators.DataRequired()])
    price = IntegerField('Price', [validators.DataRequired()])
    envImpact = IntegerField('Carbon dioxide produced (kg)', [validators.DataRequired()])
    desc = TextAreaField('Description', [validators.DataRequired()])
    image_file = FileField('Image', validators = [FileAllowed(['jpg', 'png', 'gif', 'jpeg'])])
    submit = SubmitField('Submit')

class checkoutForm(FlaskForm):
    cardNumber = StringField('Card Number', validators = [DataRequired(), Length(min = 16, max = 20)])
    cvv = StringField('CVV', validators = [DataRequired(), Length(min = 3, max =3)])
    name = StringField('Name on Card',validators = [DataRequired()])
    submit = SubmitField('Submit')

    def validateCard(self, cardNumber, cvv):
        try:
            number = str(cardNumber.data)
            digits = str(cvv.data)
            x = re.findall("[a-zA-Z]", number)
            y = re.findall("[a-zA-Z]", digits)
            if x:
                raise ValidationError("Incorrect card number")
            elif y:
                raise ValidationError("Incorrect CVV")
        except(ValueError):
                raise ValidationError("Invalid data")


class Products(db.Model):
    __tablename__ = 'products'
    id = db.Column(db.Integer, primary_key = True)
    name = db.Column(db.String(50), nullable = False, unique = True,)
    price = db.Column(db.Numeric(10, 2), nullable = False)
    desc = db.Column(db.Text, nullable = False)
    envImpact = db.Column(db.Integer, nullable = False)
    image = db.Column(db.String(150), nullable= False, default = 'image.jpg')
with app.app_context():
    db.create_all()

@app.route('/', methods = ['GET', 'POST'])
def homepage():
    return render_template('homepage.html')

@app.route('/products')
def products():
    products = Products.query.all()
    return render_template('products.html', products = products)

@app.route('/product/<int:id>')
def single_page(id):
    product = Products.query.get_or_404(id)
    return render_template('single_page.html', product = product)

@app.route('/sortbyname', methods = ['POST'])
def SortByName():
    products = Products.query.order_by(Products.name)
    return render_template('products.html', products = products)

@app.route('/sortbyprice', methods = ['POST'])
def SortByPrice():
    products = Products.query.order_by(Products.price)
    return render_template('products.html', products = products)

@app.route('/sortbyenv', methods = ['POST'])
def SortByEnv():
    products = Products.query.order_by(Products.envImpact)
    return render_template('products.html', products = products)

def MergeDicts(dict1, dict2):
    if isinstance(dict1, list) and isinstance(dict2.list):
        return dict1 + dict2
    elif isinstance(dict1, dict) and (dict2, dict):
        return dict(list(dict1.items()) + list(dict2.items()))
    return False

@app.route('/addbasket', methods = ['POST'])
def AddBasket():
    try:
        product_id = request.form.get('product_id')
        quantity = request.form.get('quantity')
        product = Products.query.filter_by(id=product_id).first()
        if product_id and quantity and request.method == "POST":
            DictItems = {product_id:{'name': product.name, 'price' : product.price, 'quantity': quantity,
            'envImpact': product.envImpact, 'image': product.image}}
            if 'shoppingCart' in session:
                if (product_id in session['shoppingCart']):
                    for key, item in session['shoppingCart'].items():
                        if int(key) == int(product_id):
                            session.modified = True
                            item['quantity'] += 1
                else:
                    session['shoppingCart'] = MergeDicts(session['shoppingCart'], DictItems)
                    return redirect(request.referrer)
            else:
                session['shoppingCart'] = DictItems
                return redirect(request.referrer)
    except Exception as e:
        print(e)
    finally:
        return redirect(request.referrer)


@app.route('/basket')
def getBasket():
    if 'shoppingCart' not in session:
        return redirect(request.referrer)
    total = 0
    grandtotal = 0
    for key, product in session['shoppingCart'].items():
        total += (float(product['price'])* int(product['quantity']))

    return render_template('basket.html', total = total)

@app.route('/updatebasket/<int:code>', methods = ['POST'])
def updatebasket(code):
    if 'shoppingCart' not in session and len(session['shoppingCart']) <= 0:
        return redirect(url_for('homepage'))
    if request.method == 'POST':
        quantity = request.form.get('quantity')
        try:
            session.modified = True
            for key, item in session['shoppingCart'].items():
                if int (key) == code:
                    item['quantity'] = quantity
                    return redirect(url_for(getBasket))

        except Exception as e:
            print(e)
            return redirect(url_for('getBasket'))

@app.route('/deleteitem/<int:id>')
def deleteitem(id):
    if 'shoppingCart' not in session or len(session['shoppingCart']) <= 0:
        return redirect(url_for('homepage'))
    try:
        session.modified = True
        for key, item in session['shoppingCart'].items():
             if int(key) == id:
                 session['shoppingCart'].pop(key, None)
                 return redirect(url_for('getBasket'))
        pass
    except Exception as e:
        print(e)
        return redirect(url_for('getBasket'))

@app.route('/clearbasket')
def clearbasket():
    try:
        session.clear()
        return redirect(url_for('products'))
    except Exception as e:
        print(e)
        return redirect(url_for('homepage'))


@app.errorhandler(404)
def notFound(e):
    return render_template('404.html')

@app.route('/checkout', methods = ['GET', 'POST'])
def checkout():
    if 'shoppingCart' not in session or len(session['shoppingCart']) <= 0:
        return redirect(url_for('getBasket'))
    form = checkoutForm()
    if form.validate_on_submit():
        session.clear()
        return redirect(url_for('checkoutsuccess'))
    return render_template('checkout.html', form = form)

@app.route('/checkoutsuccess')
def checkoutsuccess():
    return render_template('checkoutsuccess.html')


@app.route('/addproduct', methods = ['GET', 'POST'])
def addProduct():
    image = None
    form = addProductsForm()
    if form.validate_on_submit():
        name = form.name.data
        price = form.price.data
        envImpact = form.envImpact.data
        desc = form.desc.data
        image = form.image_file.data.filename
        form.image_file.data.save(os.path.join(app.static_folder, image))

        addpro = Products(name = name, price = price, envImpact = envImpact, desc = desc, image = image)
        db.session.add(addpro)
        db.session.commit()
    return render_template('addproduct.html', form = form, image = image)





if __name__ == '__main__':
    app.run(debug=True)
